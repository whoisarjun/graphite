from .graphite import Graphite
from .image_processor import process as process_image

def github():
    return 'https://github.com/whoisarjun/graphite'